                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1546607
PiGRRL Zero Raspberry Pi Zero Gameboy by adafruit is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

https://www.youtube.com/watch?v=UAIILlANNj4

***UPDATE*** The PiGRRL Zero case has been split into four pieces for printing on smaller beds! - Check the case-split.zip archive

You've seen PiGRRL, Super Game Pi, PiGRRL Pocket, PiGRRL 2 and now... it's time for PiGRRL Zero!

In this project, we'll turn the elusive $5 Raspberry Pi Zero into portable game console!

Features
-Retropie 3.7 Emulation Station: SNES, NES, SEGA, N64, and many many more!
-14 Buttons, including D-Pad, L & R shoulder, Start/Select, A, B, X, Y and two extras.
-2.2" Adafruit PiTFT 320x240 Color Display
-Landscape portable console format

The USB female jack allows you to add any peripherals to the Raspberry Pi Zero, such as a WiFi or Bluetooth adapter, USB keyboard or mouse, USB Audio Adapter or USB Hub.

Check out our full step-by-step tutorial:
https://learn.adafruit.com/pigrrl-zero